<?php 

include_once('db.php');

class Functions extends DatabasePDO {

    public $iden;
    public $name;
    public $ln;
    public $mail;
    public $pass;
    public $phone;
    public $origin;
    public $destiny;

    public function insertTicket($id,$name,$ln,$mail,$pass,$phone,$ori,$des)
    {
        try {
            $cnn = $this->conn();

            $this->iden = $id;
            $this->name = $name;
            $this->ln = $ln;
            $this->mail = $mail;
            $this->pass = $pass;
            $this->phone = $phone;
            $this->origin = $ori;
            $this->destiny = $des;

            // set the PDO error mode to exception
            $stmt = $cnn->prepare(
                    "INSERT INTO `tickets`(`Identification card`, `Name`, `Last name`, `Email`, `Password`, `Phone number`, `Origin`, `Destiny`) 
                    VALUES (:iden,:name,:ln,:mail,:pass,:phone,:origin,:destiny)");
                    $stmt->bindParam("iden", $this->iden,PDO::PARAM_STR) ;
                    $stmt->bindParam("name", $this->name,PDO::PARAM_STR) ;
                    $stmt->bindParam("ln", $this->ln,PDO::PARAM_STR) ;
                    $stmt->bindParam("mail", $this->mail,PDO::PARAM_STR) ;
                    $stmt->bindParam("pass", $this->pass,PDO::PARAM_STR) ;
                    $stmt->bindParam("phone", $this->phone,PDO::PARAM_STR) ;
                    $stmt->bindParam("origin", $this->origin,PDO::PARAM_STR) ;
                    $stmt->bindParam("destiny", $this->des,PDO::PARAM_STR) ;
            $stmt->execute();
            $count=$stmt->rowCount();
            $data=$stmt->fetch(PDO::FETCH_OBJ);
            $db = null;
            $mesage= "";
            if($count)
            {
                $mesage = "verdadero";
            }
            else
            {
                $mesage = "Falso";
            } 
            }
            catch(PDOException $e) {
            echo '{"error":{"text":'. $e->getMessage() .'}}';
            }
            return $mesage;
}
}
